# Ambient Background

A Pen created on CodePen.

Original URL: [https://codepen.io/mimikos/pen/wKqyqY](https://codepen.io/mimikos/pen/wKqyqY).

Particles with TweenMax & EaselJS